package com.entity;

public class Moderator extends Blogger 
{
	public boolean moderatesPostsAndComments()
	{
		return false;
	}

}
