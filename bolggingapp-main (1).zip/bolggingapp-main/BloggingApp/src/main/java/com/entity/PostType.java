package com.entity;

public enum PostType 
{
	TEXT,VIDEO_IMAGE,LINK,POLL;

}
